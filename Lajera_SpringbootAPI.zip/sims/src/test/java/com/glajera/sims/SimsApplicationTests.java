package com.glajera.sims;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimsApplicationTests {

	@Test
	void contextLoads() {
	}

}
