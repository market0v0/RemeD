package com.maCueva.sims.Repository;

import com.maCueva.sims.Entity.DoctorEntity;
import com.maCueva.sims.Entity.UserEntity;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<UserEntity, Integer> {

	UserEntity findByUsername(String username);

	
}
